#!/bin/bash
# Run this to get a docker container on the campus Linux machines
singularity shell docker://git-docker-classes.mst.edu/cjbgpb/cs-theory
