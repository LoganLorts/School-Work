#!/bin/bash

echo "this is not really a program, just instructions you follow once."

# On windows, to prepare, first, make sure that you:
# 1. open Powershell
# 2. wsl --install
# 3. reboot, open wsl/ubuntu
# 4. Install docker:
#
# If you are on Mac, or Windows, see the instructions here:
# https://docs.docker.com/get-docker/
#
# After installing docker, run:
# $ docker run -it fedora
# Confirm that it worked, and you're in a Fedora container.
# 
# If you are on Linux/Unix, you don't really need Docker.
# However if you want to use it, 
# you should probably use whatever docker is in the system repos.
