#!/bin/bash
# You just have to execute this once.
# In Windows, copy paste the below command without sudo.

# sudo docker build --tag "$(basename "$(pwd)")" .
sudo docker build --tag cs-theory .
